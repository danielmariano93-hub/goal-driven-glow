// Lookup helper for the single pending confirmation per (conversation,user).
// deno-lint-ignore-file no-explicit-any
import type { SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

export type PendingRow = {
  id: string;
  kind: string;
  payload: unknown;
  summary_text: string;
  status: string;
  expires_at: string;
  user_id: string;
  conversation_id: string;
};

/** Canonical executor selection used by text confirmation, app buttons and
 * tool-driven confirmation. Category Truth V2 routes transaction drafts to a
 * dedicated RPC that preserves explicit-category provenance instead of relying
 * on the legacy origin=manual heuristic. */
export function confirmationExecutor(kind: string): string {
  if (kind === "shared_expense") return "agent_execute_shared_expense_confirmation";
  if (kind === "transaction") return "agent_execute_transaction_confirmation_v2";
  return "agent_execute_confirmation";
}

export async function findPending(
  sb: SupabaseClient,
  conversation_id: string,
  user_id: string,
): Promise<PendingRow | null> {
  const { data } = await sb.from("pending_confirmations")
    .select("id, kind, payload, summary_text, status, expires_at, user_id, conversation_id")
    .eq("conversation_id", conversation_id)
    .eq("user_id", user_id)
    .eq("status", "pending")
    .gt("expires_at", new Date().toISOString())
    .maybeSingle();
  return (data as PendingRow | null) ?? null;
}

export async function findLatestPendingOrExpired(
  sb: SupabaseClient,
  conversation_id: string,
  user_id: string,
): Promise<PendingRow | null> {
  const { data } = await sb.from("pending_confirmations")
    .select("id, kind, payload, summary_text, status, expires_at, user_id, conversation_id")
    .eq("conversation_id", conversation_id)
    .eq("user_id", user_id)
    .eq("status", "pending")
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  return (data as PendingRow | null) ?? null;
}
