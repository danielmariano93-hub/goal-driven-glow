# Nino Category Truth V2 — aplicação

Base auditada: `01e0c9f8d653edb8e61f9c7f53b224e127bea07b`.

Este pacote foi desenhado para o fluxo do Meu Nino em que o ZIP é salvo primeiro em `.lovable/`. O instalador aceita apenas:

1. `HEAD` exatamente na base auditada; ou
2. commits posteriores que alterem **exclusivamente `.lovable/`**.

Qualquer drift de código aborta. A aplicação também aborta se existir alteração local fora de `.lovable/`.

## Arquitetura aplicada

`categorization_truth.v2` transforma categorização em um serviço único e resiliente:

- **write financeiro não depende da IA**: o lançamento é preservado mesmo se o classificador estiver indisponível;
- qualquer write elegível e ainda não confiável entra na `category_classification_queue`;
- worker automático a cada minuto processa a fila com lease, `SKIP LOCKED`, retry limitado e recuperação de lease;
- App mantém preflight síncrono para categorias seguras e a fila é a rede de segurança pós-write;
- AgentCore/WhatsApp/FastLog passam a gravar categoria como `user` somente quando ela foi explicitamente mencionada pelo usuário;
- MCP nunca transforma parâmetro inferido pelo modelo em verdade pessoal;
- documentos preservam edição humana, mas hints de OCR/modelo não recebem `source=user`;
- normalização canônica preserva alfanuméricos (`Souk4u`) e unifica merchant identity;
- memória pessoal materializada em `user_merchant_preferences` substitui scan de milhares de transações no hot path;
- correção pessoal vence conhecimento global;
- catálogo global curado cobre merchants de alta precisão (ex.: Autopass, Uber, Souk4u/Market4You, Carrefour etc.);
- consenso cross-user exige **>=5 usuários distintos e >=95% de concordância**, com um voto por usuário/merchant;
- só categorias da taxonomia global podem virar conhecimento cross-user; categoria customizada continua estritamente pessoal;
- LLM é fallback semântico e **nunca autoaplica sozinho**;
- category type é validado por item e também no banco;
- exceção contábil preservada: `income + refund` pode herdar categoria `expense` para estorno reduzir corretamente a categoria original.

## Integridade de dados existente

A migration remove somente categorias de linhas `movement_kind=transaction` cujo tipo é semanticamente impossível (`income→expense` ou `expense→income`) e as reenvia para a fila. Na auditoria prévia do ambiente atual foram encontrados **17** casos desse tipo.

Os **4** casos `income + movement_kind=refund + categoria expense` são intencionais e não são alterados.

Nenhuma categoria substituta é inventada pela migration.

## O que o pacote altera

- `supabase/functions/_shared/categorization/*`
- `supabase/functions/category-engine/index.ts`
- `supabase/functions/_shared/agent/tools.ts` (patch ancorado)
- `supabase/functions/_shared/agent/core/PendingConfirmations.ts`
- `supabase/functions/assistant-ingest-document/index.ts` (patch ancorado)
- `supabase/functions/_shared/documents/normalize.ts` (patch ancorado)
- `supabase/functions/assistant-review-actions/index.ts` (patch ancorado)
- `src/lib/mcp/tools/create-transaction.ts`
- `supabase/config.toml` (`category-engine` faz autenticação internamente; cron usa `x-cron-secret`)
- migration `supabase/migrations/20260809123000_category_truth_v2.sql`
- testes V2.

## Aplicação

Use primeiro `--dry-run`, depois aplique e **obrigatoriamente** execute `verify_category_truth_v2.sh` antes de commitar o código.

O verifier roda:

1. contratos estáticos de source;
2. contratos da migration;
3. `tsc` completo do projeto;
4. testes focados V2 + regressões legadas de categorização;
5. suíte Vitest completa;
6. build de produção;
7. `git diff --check`.

Somente o resultado final `NINO CATEGORY TRUTH V2 LOCAL VALIDATION: PASS` autoriza commit/push do source.

## Implantação de backend

O ZIP não implanta Supabase nem Edge Functions. Depois do commit/push da `main`, a migration e as Edge Functions precisam ser implantadas no ambiente vinculado ao projeto. Não altere SQL, thresholds, secrets ou regras durante essa etapa.
