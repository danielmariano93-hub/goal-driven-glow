#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, os, re, shutil, subprocess, sys
from pathlib import Path

BASE="01e0c9f8d653edb8e61f9c7f53b224e127bea07b"
PACKAGE_NAME="NINO_CATEGORY_TRUTH_V2_20260809.zip"

def run(args,cwd): return subprocess.check_output(args,cwd=cwd,text=True).strip()
def die(msg): print(f"ERROR: {msg}",file=sys.stderr); sys.exit(1)
def replace_once(path:Path, old:str, new:str):
    s=path.read_text(); n=s.count(old)
    if n!=1: die(f"anchor count {n} in {path}: {old[:100]!r}")
    path.write_text(s.replace(old,new,1))
def regex_once(path:Path, pattern:str, repl:str):
    s=path.read_text(); out,n=re.subn(pattern,repl,s,count=1,flags=re.S)
    if n!=1: die(f"regex anchor count {n} in {path}: {pattern[:100]!r}")
    path.write_text(out)

def verify_package(pkg:Path):
    manifest=pkg/"SHA256SUMS"
    if not manifest.exists(): die("package manifest SHA256SUMS is missing")
    for raw in manifest.read_text().splitlines():
        raw=raw.strip()
        if not raw: continue
        try: expected, rel=raw.split(None,1)
        except ValueError: die(f"invalid manifest line: {raw!r}")
        rel=rel.lstrip("* ")
        path=pkg/rel
        if not path.is_file(): die(f"package file missing: {rel}")
        actual=hashlib.sha256(path.read_bytes()).hexdigest()
        if actual!=expected: die(f"package hash mismatch: {rel}")
    print("PACKAGE: SHA256 manifest validated")

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("repo",nargs="?",default="."); ap.add_argument("--dry-run",action="store_true"); args=ap.parse_args()
    repo=Path(args.repo).resolve(); pkg=Path(__file__).resolve().parent
    verify_package(pkg)
    if not (repo/".git").exists(): die("target is not a git repository")
    head=run(["git","rev-parse","HEAD"],repo)
    if head!=BASE:
        try: changed=run(["git","diff","--name-only",f"{BASE}..HEAD"],repo).splitlines()
        except Exception: die(f"HEAD {head} is not based on audited {BASE}")
        bad=[p for p in changed if p and not p.startswith(".lovable/")]
        if bad: die("source drift since audited base: "+", ".join(bad[:20]))
        print(f"SAFE DRIFT: HEAD {head[:12]} differs only under .lovable/")
    status=run(["git","status","--porcelain"],repo).splitlines()
    bad_status=[]
    for line in status:
        p=line[3:].strip() if len(line)>=4 else line
        if " -> " in p: p=p.split(" -> ")[-1]
        if p.startswith(".lovable/"): continue
        bad_status.append(line)
    if bad_status: die("working tree has non-.lovable changes:\n"+"\n".join(bad_status[:30]))

    # Validate anchors on a temporary copy in dry-run mode.
    target=repo
    if args.dry_run:
        import tempfile
        td=Path(tempfile.mkdtemp(prefix="nino-cat-v2-")); target=td
        for rel in ["supabase/functions/assistant-ingest-document/index.ts","supabase/functions/_shared/documents/normalize.ts","supabase/functions/assistant-review-actions/index.ts","supabase/functions/_shared/agent/tools.ts","supabase/config.toml"]:
            src=repo/rel; dst=target/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)

    ingest=target/"supabase/functions/assistant-ingest-document/index.ts"
    docs_norm=target/"supabase/functions/_shared/documents/normalize.ts"
    review=target/"supabase/functions/assistant-review-actions/index.ts"
    agent_tools=target/"supabase/functions/_shared/agent/tools.ts"
    config=target/"supabase/config.toml"

    replace_once(ingest,
      'import { classifyWithContext, loadCategorizationContext } from "../_shared/categorization/engine.ts";\n',
      'import { classifyWithContext, loadCategorizationContext } from "../_shared/categorization/engine.ts";\nimport { storageMerchantKey } from "../_shared/categorization/normalize.ts";\n')
    regex_once(ingest,
      r'const uniqueRawKeys = \[\.\.\.new Set\(normalized\.map\(\(n\) => n\.rawDesc\.normalize\("NFD"\).*?\.filter\(Boolean\)\)\]\.slice\(0, 200\);',
      'const uniqueRawKeys = [...new Set(normalized.map((n) => storageMerchantKey(n.rawDesc)).filter(Boolean))].slice(0, 200);')
    replace_once(ingest,
      '    const aliasKey = rawDesc.normalize("NFD").replace(/[\\u0300-\\u036f]/g, "").toLowerCase().replace(/\\s+/g, " ").trim().slice(0, 120);',
      '    const aliasKey = storageMerchantKey(rawDesc);')
    replace_once(ingest,
      '      if (aliasHit.category_id) { categoryId = aliasHit.category_id; categorySource = "alias"; categoryConfidence = 0.98; }',
      '      // Category Truth V2: friendly name may be reused here, but category trust is decided only by the central engine.\n      // Unconfirmed legacy/import aliases must never bypass central trust filtering.')
    replace_once(ingest,
      '        explicit_category: ruleCategory ?? item.category_hint ?? null,',
      '        // Machine hints are evidence, never an explicit user choice.\n        explicit_category: null,')
    replace_once(ingest,
      '      if (central.category_id && central.action !== "leave_unresolved") {',
      '      if (central.category_id && central.action === "auto_apply") {')

    if 'import { storageMerchantKey } from "../categorization/normalize.ts";' not in docs_norm.read_text():
        docs_norm.write_text('import { storageMerchantKey } from "../categorization/normalize.ts";\n'+docs_norm.read_text())
    regex_once(docs_norm,
      r'export function aliasKeyFrom\(raw: string\): string \{\n\s*return raw\.normalize\("NFD"\).*?\n\}',
      'export function aliasKeyFrom(raw: string): string {\n  return storageMerchantKey(raw);\n}')

    if 'import { storageMerchantKey } from "../_shared/categorization/normalize.ts";' not in review.read_text():
        marker='import { fail } from "../_shared/http.ts";\n'
        replace_once(review,marker,marker+'import { storageMerchantKey } from "../_shared/categorization/normalize.ts";\n')
    regex_once(review,
      r'function aliasKey\(raw: string\): string \{\n\s*return raw\.normalize\("NFD"\).*?\n\}',
      'function aliasKey(raw: string): string {\n  return storageMerchantKey(raw);\n}')
    # Agent/WhatsApp: a model-suggested category must never be stamped as user truth.
    replace_once(agent_tools,
      'function normalizeDesc(s?: string | null): string {\n  return String(s ?? "").toLowerCase().normalize("NFD").replace(/\\p{Diacritic}/gu, "").trim();\n}\n',
      'function normalizeDesc(s?: string | null): string {\n  return String(s ?? "").toLowerCase().normalize("NFD").replace(/\\p{Diacritic}/gu, "").trim();\n}\n\nfunction normalizeExplicitCategoryText(s?: string | null): string {\n  return normalizeDesc(s).replace(/[^a-z0-9]+/g, " ").replace(/\\s+/g, " ").trim();\n}\n\nfunction isExplicitCategoryMention(userText?: string | null, category?: string | null): boolean {\n  const text = normalizeExplicitCategoryText(userText);\n  const cat = normalizeExplicitCategoryText(category);\n  if (!text || !cat) return false;\n  const cues = [\n    `categoria ${cat}`, `categoria de ${cat}`, `categoriza em ${cat}`, `categorize em ${cat}`,\n    `classifica como ${cat}`, `classifique como ${cat}`, `coloca em ${cat}`, `coloque em ${cat}`,\n    `lanca em ${cat}`, `registre em ${cat}`, `registra em ${cat}`,\n  ];\n  return cues.some((cue) => text.includes(cue));\n}\n')
    replace_once(agent_tools,
      '  const occurred_at = resolveOccurredAt({ text: ctx.user_text, modelValue: args.occurred_at ?? null }).iso;\n  const cat = await resolveCategoryId(ctx, args.category, args.type);',
      '  const occurred_at = resolveOccurredAt({ text: ctx.user_text, modelValue: args.occurred_at ?? null }).iso;\n  // Category Truth V2: only a category literally requested by the user may enter the draft as user truth.\n  // Any model-inferred category stays null and is resolved by the central queue after confirmation.\n  const explicitCategoryHint = isExplicitCategoryMention(ctx.user_text, args.category) ? args.category : undefined;\n  const cat = await resolveCategoryId(ctx, explicitCategoryHint, args.type);')
    replace_once(agent_tools,
      '      category_id: cat,\n      payment_method: "credit_card",',
      '      category_id: cat,\n      category_explicit: Boolean(cat && explicitCategoryHint),\n      payment_method: "credit_card",')
    replace_once(agent_tools,
      '  const payload = { type: args.type, amount, account_id: acc.id, category_id: cat, occurred_at, description: args.description ?? null, payment_method: "account" };',
      '  const payload = { type: args.type, amount, account_id: acc.id, category_id: cat, category_explicit: Boolean(cat && explicitCategoryHint), occurred_at, description: args.description ?? null, payment_method: "account" };')

    # Cron calls use x-cron-secret; category-engine authenticates internally. Disable gateway JWT
    # verification for this one function so the cron secret can reach the handler.
    cfg=config.read_text()
    if '[functions.category-engine]' not in cfg:
        config.write_text(cfg.rstrip()+"\n\n[functions.category-engine]\nverify_jwt = false\n")

    if args.dry_run:
        print("DRY RUN: all source anchors validated")
        shutil.rmtree(target)
        return

    # Overlay canonical files + tests + migration.
    overlay=pkg/"overlay"
    for src in overlay.rglob("*"):
        if src.is_file():
            rel=src.relative_to(overlay); dst=repo/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
    print("APPLY: Category Truth V2 sources installed")

if __name__=="__main__": main()
