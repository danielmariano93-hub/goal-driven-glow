#!/usr/bin/env bash
set -euo pipefail
REPO="${1:-.}"
cd "$REPO"

echo "[1/7] Source contracts"
grep -q 'CATEGORY_ENGINE_VERSION = "categorization_truth.v2"' supabase/functions/_shared/categorization/engine.ts
! grep -q 'row.type === "both"' supabase/functions/_shared/categorization/engine.ts
grep -q 'const history:HistoryRow\[\]=\[\]' supabase/functions/_shared/categorization/engine.ts
! grep -q 'sb.from("transactions").select("description,raw_description' supabase/functions/_shared/categorization/engine.ts
grep -q 'storageMerchantKey(n.rawDesc)' supabase/functions/assistant-ingest-document/index.ts
grep -q 'explicit_category: null' supabase/functions/assistant-ingest-document/index.ts
grep -q 'central.action === "auto_apply"' supabase/functions/assistant-ingest-document/index.ts
grep -q 'return storageMerchantKey(raw);' supabase/functions/_shared/documents/normalize.ts
grep -q 'return storageMerchantKey(raw);' supabase/functions/assistant-review-actions/index.ts
grep -q 'isExplicitCategoryMention(ctx.user_text, args.category)' supabase/functions/_shared/agent/tools.ts
grep -q 'resolveCategoryId(ctx, explicitCategoryHint, args.type)' supabase/functions/_shared/agent/tools.ts
grep -q 'category_explicit: Boolean(cat && explicitCategoryHint)' supabase/functions/_shared/agent/tools.ts
grep -q 'agent_execute_transaction_confirmation_v2' supabase/functions/_shared/agent/core/PendingConfirmations.ts
grep -q '\[functions.category-engine\]' supabase/config.toml
grep -A2 '\[functions.category-engine\]' supabase/config.toml | grep -q 'verify_jwt = false'
grep -q 'category_source: categoryId ? "document_hint" : null' src/lib/mcp/tools/create-transaction.ts
grep -q '\.eq("type", type)' src/lib/mcp/tools/create-transaction.ts
grep -q 'process_queue_global' supabase/functions/category-engine/index.ts
grep -q 'TRUSTED_APPLIED_SOURCES' supabase/functions/category-engine/index.ts
grep -q 'category_id:null,category_source:null,category_confidence:null,category_reason:null' supabase/functions/category-engine/index.ts

echo "[2/7] Migration contracts"
MIG='supabase/migrations/20260809123000_category_truth_v2.sql'
grep -q 'category_merchant_key' "$MIG"
grep -q 'user_merchant_preferences' "$MIG"
grep -q 'merchant_global_votes' "$MIG"
grep -q 'merchant_global_knowledge' "$MIG"
grep -q 'agent_execute_transaction_confirmation_v2' "$MIG"
grep -q 'tg_transactions_category_audit' "$MIG"
grep -q 'inherit_document_category_provenance' "$MIG"
grep -q 'transactions_00_document_category_provenance' "$MIG"
grep -q 'FOR UPDATE OF q SKIP LOCKED' "$MIG"
grep -q 'q.attempts < 5' "$MIG"
grep -q 'total_users>=5 AND agreement>=0.95' "$MIG"
grep -q 'category_type_mismatch' "$MIG"
grep -q "movement_kind,'transaction')='refund'" "$MIG"
grep -q 'category_truth_v2_cron_secret_missing' "$MIG"
grep -q 'nino-category-truth-v2-worker' "$MIG"
grep -q "'personal','alias','history','global','rule'" "$MIG"
grep -q 'g.user_id IS NULL' "$MIG"
grep -q 'GRANT SELECT,INSERT,UPDATE,DELETE ON TABLE public.merchant_global_knowledge TO service_role' "$MIG"

echo "[3/7] TypeScript"
npx tsc -p tsconfig.app.json --noEmit

echo "[4/7] Focused tests"
npx vitest run \
  src/test/category-truth-v2.test.ts \
  src/test/category-truth-v2-source-contract.test.ts \
  src/test/categorization-pipeline.test.ts

echo "[5/7] Full test suite"
npx vitest run

echo "[6/7] Production build"
npm run build

echo "[7/7] Patch hygiene"
git diff --check
printf '\nNINO CATEGORY TRUTH V2 LOCAL VALIDATION: PASS\n'
git status --short
git diff --stat
