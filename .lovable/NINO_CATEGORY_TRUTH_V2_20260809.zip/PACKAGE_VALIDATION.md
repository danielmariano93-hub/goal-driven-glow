# Category Truth V2 — validação realizada antes do empacotamento

Base: `01e0c9f8d653edb8e61f9c7f53b224e127bea07b`.

## Passou localmente

- compilação TypeScript isolada dos módulos canônicos (`normalize`, `merchantCatalog`, `pipeline`, `engine`) com TypeScript 5.8.3;
- transpile/syntax check de `category-engine`, MCP, PendingConfirmations e testes V2;
- runtime contract test real dos módulos V2:
  - `Souk4u` preserva dígito;
  - `PAY Souk4u 123456 → souk4u`;
  - `Autopass s.a*atm Tmob → autopass`;
  - preferência pessoal Souk4u/Alimentação vence global Mercado;
  - usuário sem preferência usa global Mercado;
  - Autopass resolve Transporte;
  - Uber Eats não é confundido com corrida Uber;
  - LLM não autoaplica;
  - category ID fora do tipo é rejeitado;
  - shared expense é excluído da categorização de consumo;
- `python3 -m py_compile apply_category_truth_v2.py`;
- `bash -n verify_category_truth_v2.sh`;
- compatibilidade read-only com o schema de produção para colunas, enums, constraints, queue, `pg_cron`, `pg_net` e Vault secret existente;
- emulação read-only do merchant key proposto contra PostgreSQL, confirmando os casos críticos;
- auditoria read-only dos dados existentes confirmou a necessidade da exceção de refund e do reparo conservador de type mismatch.

## Refinamentos feitos após a segunda auditoria

- removido scan de até 3.000 transações do hot path: memória pessoal agora é materializada;
- histórico legacy/import/model não é promovido como evidência pessoal;
- source-less `origin=manual` deixa de ser automaticamente tratado como verdade do usuário;
- global learning passa a aceitar somente slugs existentes na taxonomia global;
- service_role recebeu grants explícitos nas novas tabelas;
- Agent transaction confirmation ganhou RPC V2 com provenance explícita;
- cron não depende de `app.settings.anon_key`; `category-engine` faz auth interna.

## Gate que precisa rodar no Codespace

O ambiente desta geração não contém um checkout completo executável do repositório, portanto a suíte inteira e o build final não podem ser certificados aqui. O pacote transforma isso em gate obrigatório antes do commit:

`verify_category_truth_v2.sh` executa `tsc`, testes focados, **Vitest completo**, build e diff check no checkout real do usuário e para no primeiro erro.

Não commitar o source se o verifier não terminar com:

`NINO CATEGORY TRUTH V2 LOCAL VALIDATION: PASS`
