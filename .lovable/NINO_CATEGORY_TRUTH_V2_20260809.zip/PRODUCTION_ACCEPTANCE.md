# Category Truth V2 — gates de produção

Aprovar somente depois de todos os gates abaixo.

## Funcionais

1. **App / personal override:** Daniel registra `Souk4u` sem escolher categoria → `Alimentação`, source `personal`.
2. **App / global curated:** registrar `Autopass s.a*atm Tmob` sem categoria → `Transporte`, source `global`.
3. **Usuário sem preferência:** `Souk4u` → `Mercado` pelo catálogo global.
4. **Agent/WhatsApp sem categoria explícita:** `gastei 10 no Autopass` → write ocorre mesmo sem classificador; fila resolve para Transporte automaticamente.
5. **Agent/WhatsApp com categoria explícita:** `gastei 10 no Autopass, categoria Transporte` → grava imediatamente como `source=user`, confidence 1.
6. **MCP:** category de tipo incompatível é rejeitada; hint do modelo nunca vira `source=user`.
7. **Documento:** hint automático não vira `user`; edição manual na revisão preserva provenance `user`.
8. **LLM:** decisão isolada é `suggest_review`, nunca `auto_apply`.
9. **Proteção de escolha humana:** worker nunca sobrescreve category com source confiável (`user/personal/alias/history/global/rule`).

## Integridade

10. Nenhuma nova linha `movement_kind=transaction` com category type incompatível.
11. `income + movement_kind=refund + expense category` continua permitido.
12. `category_decisions.engine_version = categorization_truth.v2` nas decisões V2.
13. `user_merchant_preferences` contém as correções pessoais esperadas após backfill (incluindo Autopass/Souk4u quando houver evidência explícita).
14. Categoria customizada do usuário não aparece como conhecimento global verificável.
15. `merchant_global_knowledge` só verifica consenso com >=5 usuários e >=95% agreement.

## Operação

16. Cron `nino-category-truth-v2-worker` ativo.
17. Cron `nino-category-global-consensus` ativo.
18. `category-engine` responde ao cron autenticado por `x-cron-secret` e rejeita chamada global sem segredo.
19. Nenhuma fila `processing` fica presa por >5 minutos; lease stale é recuperado.
20. Itens `failed` param após 5 tentativas e permanecem visíveis para revisão, sem inventar categoria.
21. O build SHA implantado deve corresponder ao commit aprovado na `main`.

## Observação sobre o primeiro processamento

A fila que já existia antes do V2 será consumida automaticamente. Categorias de alta confiança podem ser aplicadas; casos ambíguos permanecem sem categoria/sugeridos. Não usar threshold menor para “forçar” cobertura.
