# Patch contents — V9

## Correções de comportamento

1. **Single weekday behavioral truth** — `weekday.behavioral-truth.v5`.
2. **Mandatory abstention** — sem conclusão quando decisão não é `established`.
3. **Behavioral date parity** — antecipação e assessor usam `resolveBehavioralDate`.
4. **Category schema parity** — remove `category_type="both"` e valida UUID/type.
5. **WhatsApp data-plane telemetry** — correlação de ponta a ponta sanitizada.
6. **WAHA webhook self-heal** — watchdog valida e sincroniza webhook divergente.
7. **Operational health** — sessão `WORKING` não é mais sinônimo de data plane verificado.
8. **Release gates** — golden tests, schema contracts, channel parity e E2E checklist.

## Arquivos no overlay

O diretório `overlay/` contém arquivos novos ou substituições completas. `apply_v9.py`
cuida das edições cirúrgicas em arquivos existentes e exige as âncoras da base auditada.
