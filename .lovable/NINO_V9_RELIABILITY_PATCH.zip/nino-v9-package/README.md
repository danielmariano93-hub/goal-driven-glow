# Meu Nino — Reliability & Behavioral Truth V9

**Base auditada:** `65c9d5ce949273a2f6611aae1792295aa6425d1c`  
**Objetivo:** corrigir os defeitos comprovados após o V8 sem criar outro motor financeiro paralelo.

> Este pacote **não foi aplicado no GitHub, Lovable ou Supabase**. Ele foi gerado para revisão/aplicação local sobre a base acima.

## O que este patch corrige

### 1. “R$ 782,30 por sexta” / padrão semanal incorreto

Cria `weekday.behavioral-truth.v5` como **única política estatística** para responder “em qual dia eu costumo gastar mais?”.

- usa gasto **ajustável**, não qualquer despesa;
- usa `behavioral_day` e confiança temporal;
- inclui ocorrências sem gasto no denominador;
- separa dias excepcionais e outliers;
- exige amostra, janela, cobertura, consistência e separação contra o 2º colocado;
- `insufficient`, `candidate` e `ambiguous` agora significam **ABSTENÇÃO**;
- somente `established` autoriza uma resposta numérica de comportamento típico;
- Assessor e Antecipação passam a consumir a mesma verdade.

O caso que anteriormente produzia `R$ 782,30` virou um golden test obrigatório e **não pode mais produzir vencedor público**.

### 2. Divergência `occurred_at` × `behavioral_day`

O motor de antecipação também passa por `resolveBehavioralDate()` antes de formar fatos comportamentais. Datas com confiança `< 0,65` continuam válidas para a contabilidade, mas **não podem virar afirmações comportamentais**.

### 3. `category_type = "both"` quebrando Before Spending

O schema real aceita apenas `income | expense`. O patch:

- remove consultas por `"both"`;
- filtra pelo `type` real;
- valida o `type` também quando o agente recebe uma categoria por UUID;
- adiciona contract test para impedir regressão.

### 4. WhatsApp “verde” porém sem responder

Adiciona observabilidade do data plane:

`webhook_received → inbound_persisted → agent_started → agent_completed → outbound_queued → provider_sent → ack_received`

Com isso:

- vínculo ativo deixa de equivaler a “canal saudável”;
- `whatsapp-session` expõe `data_plane` e `webhook_ok`;
- o watchdog valida a configuração real da WAHA;
- webhook divergente é **auto-reparado** pelo watchdog via `syncWebhook`;
- falhas ficam correlacionadas e sanitizadas em `whatsapp_pipeline_events`;
- nenhum corpo de mensagem, telefone, URL ou segredo é persistido nessa telemetria.

## Arquivos principais

Novos/substituídos:

- `supabase/functions/_shared/analytics/weekdayTruth.ts`
- `supabase/functions/_shared/analytics/weekdayPattern.ts`
- `supabase/functions/_shared/intelligence/weekdayTool.ts`
- `supabase/functions/_shared/intelligence/evidence.ts`
- `supabase/functions/_shared/intelligence/metricRegistry.ts`
- `supabase/functions/_shared/messaging/pipelineTelemetry.ts`
- `supabase/migrations/20260807235900_nino_reliability_truth_v9.sql`
- testes V9 em `src/test/`

Alterados pelo instalador:

- `supabase/functions/_shared/anticipation/facts.ts`
- `supabase/functions/_shared/anticipation/runner.ts`
- `supabase/functions/_shared/anticipation/patterns.ts`
- `supabase/functions/_shared/agent/tools.ts`
- `supabase/functions/whatsapp-webhook/index.ts`
- `supabase/functions/whatsapp-send/index.ts`
- `supabase/functions/whatsapp-session/index.ts`
- `supabase/functions/whatsapp-ack-watchdog/index.ts`

## Como aplicar

Em uma cópia limpa do repositório no SHA auditado:

```bash
python3 apply_v9.py /caminho/para/goal-driven-glow --dry-run
python3 apply_v9.py /caminho/para/goal-driven-glow --emit-patch /tmp/NINO_V9_RELIABILITY.patch
```

O instalador recusa por padrão qualquer HEAD diferente de `65c9d5c...`. Isso é intencional: evita aplicar correções sobre uma base que mudou sem revisão.

Depois:

```bash
./verify_v9.sh /caminho/para/goal-driven-glow
```

A validação local executa contract tests V9, typecheck e suíte completa.

## Ordem de implantação

1. Revisar `git diff` gerado pelo instalador.
2. Commitar/subir a alteração no GitHub.
3. Aplicar `20260807235900_nino_reliability_truth_v9.sql` no Supabase vinculado.
4. Redeploy das Edge Functions afetadas:
   - `agent-chat`
   - `agent-run`
   - `whatsapp-webhook`
   - `whatsapp-send`
   - `whatsapp-session`
   - `whatsapp-ack-watchdog`
   - `anticipation-tick`
   - `agent-proactive-tick`
   - `nino-intelligence-tick`
5. Publicar o app somente depois dos gates locais verdes.
6. Executar **todos os gates de produção** descritos em `ACCEPTANCE.md`.

## O que significa “100%” neste pacote

Não existe garantia técnica séria de “100% em produção” antes de executar o código no ambiente real, com sessão WAHA, banco e usuário autenticado. Por isso este pacote transforma a meta em **gates objetivos**:

- se a amostra semanal não permite conclusão, o Nino é obrigado a se abster;
- se o schema divergir, contract test falha;
- se App e WhatsApp deixarem de usar o mesmo Core/verdade semanal, teste falha;
- se o WhatsApp não completar o data plane, o canal deixa de ser considerado verificado;
- o release só deve ser aceito quando os testes reais em `ACCEPTANCE.md` passarem.

Isso elimina os três tipos de falso positivo que ocorreram no V8: “teste verde com métrica errada”, “Edge online mas fluxo E2E quebrado” e “schema compilando mas falhando em runtime”.
