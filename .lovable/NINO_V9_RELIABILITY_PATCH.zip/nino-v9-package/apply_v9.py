#!/usr/bin/env python3
"""Apply Meu Nino Reliability / Behavioral Truth v9 to the exact audited base.

Default behavior is intentionally strict: the repository HEAD must equal the
SHA audited when this package was generated. Use --allow-drift only after a
human has reviewed the intervening diff.
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys

BASE_SHA = "65c9d5ce949273a2f6611aae1792295aa6425d1c"
PACKAGE_DIR = Path(__file__).resolve().parent
OVERLAY_DIR = PACKAGE_DIR / "overlay"


def run(cmd: list[str], cwd: Path, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, cwd=cwd, check=check, text=True, capture_output=True)


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected exactly one match, found {count}")
    return text.replace(old, new, 1)


def splice(text: str, start_marker: str, end_marker: str, replacement: str, label: str) -> str:
    start = text.find(start_marker)
    if start < 0:
        raise RuntimeError(f"{label}: start marker not found")
    end = text.find(end_marker, start)
    if end < 0:
        raise RuntimeError(f"{label}: end marker not found")
    return text[:start] + replacement + text[end:]


def copy_overlay(repo: Path, dry_run: bool) -> list[str]:
    changed: list[str] = []
    for src in sorted(OVERLAY_DIR.rglob("*")):
        if not src.is_file():
            continue
        rel = src.relative_to(OVERLAY_DIR)
        dst = repo / rel
        changed.append(str(rel))
        if not dry_run:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
    return changed


def patch_anticipation_facts(repo: Path, dry_run: bool) -> str:
    path = repo / "supabase/functions/_shared/anticipation/facts.ts"
    text = read(path)
    if 'from "../analytics/behavioralDate.ts"' not in text:
        text = replace_once(
            text,
            '} from "./contracts.ts";\n',
            '} from "./contracts.ts";\nimport { resolveBehavioralDate } from "../analytics/behavioralDate.ts";\n',
            "anticipation/facts import",
        )
    text = replace_once(
        text,
        '  category_confidence?: number | null;\n};',
        '  category_confidence?: number | null;\n  behavioral_day?: string | null;\n  behavior_date_source?: string | null;\n  behavior_date_confidence?: number | string | null;\n};',
        "anticipation/facts behavioral fields",
    )
    text = replace_once(
        text,
        '    const localDate = String(row.occurred_at).slice(0, 10);\n    if (!/^\\d{4}-\\d{2}-\\d{2}$/.test(localDate)) continue;',
        '    const behaviorDate = resolveBehavioralDate(row);\n    const localDate = behaviorDate.day;\n    if (!/^\\d{4}-\\d{2}-\\d{2}$/.test(localDate)) continue;',
        "anticipation/facts date source",
    )
    text = replace_once(
        text,
        '    if (!excludedKind && !isTransfer && !isCardPayment && !isDebtPrincipal && !isPlanned) {',
        '    if (behaviorDate.eligibleForBehavior && !excludedKind && !isTransfer && !isCardPayment && !isDebtPrincipal && !isPlanned) {',
        "anticipation/facts confidence gate",
    )
    text = replace_once(
        text,
        '      data_confidence: row.category_id ? 1 : 0.6,',
        '      data_confidence: Math.min(behaviorDate.confidence, row.category_id ? 1 : 0.6),',
        "anticipation/facts confidence propagation",
    )
    if not dry_run:
        write(path, text)
    return str(path.relative_to(repo))


def patch_anticipation_runner(repo: Path, dry_run: bool) -> str:
    path = repo / "supabase/functions/_shared/anticipation/runner.ts"
    text = read(path)
    old = 'const TX_FIELDS = "id,account_id,category_id,type,status,amount,occurred_at,description,transfer_group_id,payment_method,credit_card_id,settles_card_id,movement_kind,posted_at,competence_date,occurred_at_time,occurred_at_timezone,occurred_at_precision,category_source,category_confidence";'
    new = 'const TX_FIELDS = "id,account_id,category_id,type,status,amount,occurred_at,behavioral_day,behavior_date_source,behavior_date_confidence,description,transfer_group_id,payment_method,credit_card_id,settles_card_id,movement_kind,posted_at,competence_date,occurred_at_time,occurred_at_timezone,occurred_at_precision,category_source,category_confidence";'
    text = replace_once(text, old, new, "anticipation/runner TX_FIELDS")
    if not dry_run:
        write(path, text)
    return str(path.relative_to(repo))


def patch_agent_tools(repo: Path, dry_run: bool) -> str:
    path = repo / "supabase/functions/_shared/agent/tools.ts"
    text = read(path)
    old_filter = '.in("type", [type, "both"] as any)'
    count = text.count(old_filter)
    if count != 4:
        raise RuntimeError(f"agent/tools category type filter: expected 4 matches, found {count}")
    text = text.replace(old_filter, '.eq("type", type)')
    text = replace_once(
        text,
        '    const { data, error } = await ctx.sb.from("categories").select("id,user_id")\n      .eq("id", hintOrId).is("archived_at", null).maybeSingle();\n    if (error) throw new Error(`categories_query_failed:${error.message}`);\n    if (!data) return null;\n    if (data.user_id && data.user_id !== ctx.user_id) return null;\n    return data.id as string;',
        '    const { data, error } = await ctx.sb.from("categories").select("id,user_id,type")\n      .eq("id", hintOrId).is("archived_at", null).maybeSingle();\n    if (error) throw new Error(`categories_query_failed:${error.message}`);\n    if (!data) return null;\n    if (data.user_id && data.user_id !== ctx.user_id) return null;\n    if (String((data as any).type) !== type) return null;\n    return data.id as string;',
        "agent/tools UUID category type validation",
    )
    if not dry_run:
        write(path, text)
    return str(path.relative_to(repo))


def patch_anticipation_patterns(repo: Path, dry_run: bool) -> str:
    path = repo / "supabase/functions/_shared/anticipation/patterns.ts"
    text = read(path)
    if 'from "../analytics/weekdayPattern.ts"' not in text:
        marker = '} from "./contracts.ts";\n'
        text = replace_once(
            text,
            marker,
            marker + 'import { computeWeekdayPatternFromDailyFacts } from "../analytics/weekdayPattern.ts";\n',
            "anticipation/patterns shared truth import",
        )

    replacement = '''  // 1. Dia da semana — usa exatamente a mesma verdade comportamental do Assessor.\n  const weekdayConfig = input.configs.get("weekday_spending_risk");\n  if (weekdayConfig && usable.length > 0) {\n    const from = usable[0].local_date;\n    const to = usable[usable.length - 1].local_date;\n    const cfgMinSample = Number.isFinite(Number(weekdayConfig.min_sample)) ? Number(weekdayConfig.min_sample) : 4;\n    const cfgWindowDays = Number.isFinite(Number(weekdayConfig.min_window_days)) ? Number(weekdayConfig.min_window_days) : 56;\n    const cfgCoverage = Number.isFinite(Number(weekdayConfig.min_coverage)) ? Number(weekdayConfig.min_coverage) : 0.65;\n    const cfgUplift = Number.isFinite(Number(weekdayConfig.min_uplift_pct)) ? Number(weekdayConfig.min_uplift_pct) : 20;\n    const cfgAbsDelta = Number.isFinite(Number(weekdayConfig.min_absolute_delta)) ? Number(weekdayConfig.min_absolute_delta) : 20;\n    const truth = computeWeekdayPatternFromDailyFacts({\n      days: usable,\n      from,\n      to,\n      coverage: input.coverage,\n      policy: {\n        min_weeks: Math.max(8, Math.ceil(cfgWindowDays / 7)),\n        min_active_days_candidate: Math.max(4, Math.min(6, cfgMinSample)),\n        min_active_days_established: Math.max(6, cfgMinSample),\n        min_total_active_days: Math.max(14, cfgMinSample * 2),\n        min_data_coverage: cfgCoverage,\n        min_separation_pct: Math.max(0.15, cfgUplift / 200),\n        min_separation_amount: Math.max(20, cfgAbsDelta / 2),\n        min_consistency: 0.5,\n      },\n    });\n\n    const comparable = truth.weekdays.filter((row) => row.typical_amount > 0);\n    const typicalValues = comparable.map((row) => row.typical_amount);\n    for (const row of comparable) {\n      if (row.clean_active_days < Math.max(4, Math.min(6, cfgMinSample))) continue;\n      const otherValues = comparable\n        .filter((other) => other.weekday !== row.weekday)\n        .map((other) => other.typical_amount)\n        .filter((value) => value > 0);\n      const baseline = median(otherValues);\n      const delta = round2(row.typical_amount - baseline);\n      const uplift = baseline > 0 ? round2((delta / baseline) * 100) : 100;\n      const isEstablishedWinner = truth.decision === "established" && truth.winner?.weekday === row.weekday;\n      const separationBlocked = truth.decision === "ambiguous" && truth.candidate?.weekday === row.weekday;\n      const blockReasons = Object.entries(truth.gates)\n        .filter(([, ok]) => !ok)\n        .map(([criterion]) => ({ criterion, observed: false, required: true }));\n      if (separationBlocked) {\n        blockReasons.push({ criterion: "weekday_separation", observed: false, required: true });\n      }\n\n      out.push({\n        user_id: input.userId,\n        detector: "weekday_spending_risk",\n        pattern_key: `weekday:${row.weekday}`,\n        label: `Gasto ajustável maior na ${WEEKDAY_LABELS[row.weekday]}`,\n        status: isEstablishedWinner ? "validated" : "candidate",\n        sample_size: row.clean_active_days,\n        window_start: from,\n        window_end: to,\n        baseline_value: round2(baseline),\n        pattern_value: row.typical_amount,\n        uplift_pct: uplift,\n        absolute_delta: delta,\n        hit_rate: row.active_rate,\n        consistency: row.consistency,\n        confidence: isEstablishedWinner\n          ? (truth.confidence === "high" ? 0.9 : 0.75)\n          : truth.decision === "ambiguous" ? 0.45 : 0.4,\n        data_coverage: input.coverage,\n        evidence: {\n          truth_formula_version: truth.formula_version,\n          truth_decision: truth.decision,\n          truth_candidate_weekday: truth.candidate?.weekday ?? null,\n          truth_winner_weekday: truth.winner?.weekday ?? null,\n          truth_runner_up_weekday: truth.runner_up?.weekday ?? null,\n          truth_gates: truth.gates,\n          limitations: truth.limitations,\n          block_reasons: blockReasons,\n          metric: row,\n          excluded_outliers: row.outlier_count,\n          comparable_typical_values: typicalValues,\n        },\n        exclusions: [\n          "transferências internas",\n          "pagamento de fatura",\n          "aplicações e resgates",\n          "principal de dívida",\n          "lançamentos planejados",\n          "datas comportamentais de baixa confiança",\n          "dias extraordinários",\n        ],\n        formula_version: ANTICIPATION_FORMULA_VERSION,\n        detector_version: "v2",\n      });\n    }\n  }\n'''
    text = splice(
        text,
        "  // 1. Dia da semana",
        "  // 2. Fim de semana",
        replacement,
        "anticipation/patterns weekday branch",
    )
    if not dry_run:
        write(path, text)
    return str(path.relative_to(repo))


def patch_whatsapp_webhook(repo: Path, dry_run: bool) -> str:
    path = repo / "supabase/functions/whatsapp-webhook/index.ts"
    text = read(path)
    if 'pipelineTelemetry.ts' not in text:
        text = replace_once(
            text,
            'import { getWahaAccess } from "../_shared/messaging/waha.ts";\n',
            'import { getWahaAccess } from "../_shared/messaging/waha.ts";\nimport { recordWhatsappPipelineEvent } from "../_shared/messaging/pipelineTelemetry.ts";\n',
            "whatsapp-webhook telemetry import",
        )

    text = replace_once(
        text,
        '  const sb = createClient(SUPABASE_URL, SERVICE_ROLE, {\n    auth: { persistSession: false, autoRefreshToken: false },\n  });\n\n  // ACKs are delivery telemetry, not inbound user messages.',
        '  const sb = createClient(SUPABASE_URL, SERVICE_ROLE, {\n    auth: { persistSession: false, autoRefreshToken: false },\n  });\n  const rootMeta = (payload ?? {}) as Record<string, any>;\n  await recordWhatsappPipelineEvent(sb, {\n    stage: "webhook_received",\n    session: typeof rootMeta.session === "string" ? rootMeta.session : null,\n    metadata: { event: String(rootMeta.event ?? rootMeta.type ?? "unknown").slice(0, 80) },\n  });\n\n  // ACKs are delivery telemetry, not inbound user messages.',
        "whatsapp-webhook received telemetry",
    )

    text = replace_once(
        text,
        '    const matched = Array.isArray(applied) && applied.length > 0;\n    return json({ ok: true, ack: ack.status, matched });',
        '    const matched = Array.isArray(applied) && applied.length > 0;\n    const { data: ackOutbound } = await sb.from("outbound_messages")\n      .select("id,user_id,inbound_message_id")\n      .eq("provider_message_id", ack.providerMessageId)\n      .order("created_at", { ascending: false }).limit(1).maybeSingle();\n    await recordWhatsappPipelineEvent(sb, {\n      stage: "ack_received",\n      user_id: (ackOutbound as any)?.user_id ?? null,\n      inbound_message_id: (ackOutbound as any)?.inbound_message_id ?? null,\n      outbound_message_id: (ackOutbound as any)?.id ?? null,\n      provider_message_id: ack.providerMessageId,\n      metadata: { ack: ack.status, matched },\n    });\n    return json({ ok: true, ack: ack.status, matched });',
        "whatsapp-webhook ack telemetry",
    )

    text = replace_once(
        text,
        '      await sb.from("provider_health_events").insert({\n        provider: "waha",\n        ok: sessionStatus.ok,\n        error_masked: sessionStatus.status.slice(0, 120),\n      });',
        '      await sb.from("provider_health_events").insert({\n        provider: "waha",\n        ok: sessionStatus.ok,\n        error_masked: sessionStatus.status.slice(0, 120),\n      });\n      await recordWhatsappPipelineEvent(sb, {\n        stage: "provider_session", ok: sessionStatus.ok,\n        session: getSessionName(), error_code: sessionStatus.ok ? null : sessionStatus.status,\n      });',
        "whatsapp-webhook session telemetry",
    )

    text = replace_once(
        text,
        '  if (!classified.ok) {\n    await logDrop(sb, {',
        '  if (!classified.ok) {\n    await recordWhatsappPipelineEvent(sb, {\n      stage: "webhook_dropped", ok: false, session: classified.session,\n      error_code: classified.reason,\n      metadata: { event: classified.event ?? "unknown" },\n    });\n    await logDrop(sb, {',
        "whatsapp-webhook drop telemetry",
    )

    text = replace_once(
        text,
        '  const inbound_message_id = inb!.id as string;\n\n  const code = extractLinkCode(evt.body);',
        '  const inbound_message_id = inb!.id as string;\n  await recordWhatsappPipelineEvent(sb, {\n    stage: "inbound_persisted", inbound_message_id,\n    provider_message_id: evt.provider_message_id, session: getSessionName(),\n  });\n\n  const code = extractLinkCode(evt.body);',
        "whatsapp-webhook inbound telemetry",
    )

    old_success = '''    try {\n      await runOrchestrator({\n      user_id: link.user_id, conversation_id: conversationId,\n        inbound_message_id, text: evt.body, to_phone: evt.from_phone, source: "whatsapp",\n      });\n      await sb.from("inbound_messages").update({ processed_at: new Date().toISOString() }).eq("id", inbound_message_id);\n    } catch (e) {'''
    new_success = '''    try {\n      await recordWhatsappPipelineEvent(sb, {\n        stage: "agent_started", user_id: link.user_id as string,\n        inbound_message_id, provider_message_id: evt.provider_message_id, session: getSessionName(),\n      });\n      const orchestrated = await runOrchestrator({\n        user_id: link.user_id, conversation_id: conversationId,\n        inbound_message_id, text: evt.body, to_phone: evt.from_phone, source: "whatsapp",\n      });\n      await recordWhatsappPipelineEvent(sb, {\n        stage: "agent_completed", user_id: link.user_id as string,\n        inbound_message_id, agent_run_id: orchestrated.run_id ?? null,\n        provider_message_id: evt.provider_message_id, session: getSessionName(),\n        metadata: { path: String(orchestrated.path ?? "unknown").slice(0, 80) },\n      });\n      const { data: queuedOutbound } = await sb.from("outbound_messages")\n        .select("id,user_id")\n        .eq("inbound_message_id", inbound_message_id)\n        .order("created_at", { ascending: false }).limit(1).maybeSingle();\n      if ((queuedOutbound as any)?.id) {\n        await recordWhatsappPipelineEvent(sb, {\n          stage: "outbound_queued", user_id: (queuedOutbound as any).user_id ?? link.user_id,\n          inbound_message_id, outbound_message_id: (queuedOutbound as any).id,\n          agent_run_id: orchestrated.run_id ?? null,\n        });\n      }\n      await sb.from("inbound_messages").update({ processed_at: new Date().toISOString() }).eq("id", inbound_message_id);\n    } catch (e) {'''
    text = replace_once(text, old_success, new_success, "whatsapp-webhook agent telemetry")

    text = replace_once(
        text,
        '      console.error("[webhook] orchestrator failed", sanitized);\n      const idem = `orch-err:${inbound_message_id}`;',
        '      console.error("[webhook] orchestrator failed", sanitized);\n      await recordWhatsappPipelineEvent(sb, {\n        stage: "failed", ok: false, user_id: link.user_id as string,\n        inbound_message_id, provider_message_id: evt.provider_message_id,\n        session: getSessionName(), error_code: sanitized,\n      });\n      const idem = `orch-err:${inbound_message_id}`;',
        "whatsapp-webhook failure telemetry",
    )

    if not dry_run:
        write(path, text)
    return str(path.relative_to(repo))


def patch_whatsapp_sender(repo: Path, dry_run: bool) -> str:
    path = repo / "supabase/functions/whatsapp-send/index.ts"
    text = read(path)
    if 'pipelineTelemetry.ts' not in text:
        text = replace_once(
            text,
            'import { writeJobHeartbeat } from "../_shared/heartbeats.ts";\n',
            'import { writeJobHeartbeat } from "../_shared/heartbeats.ts";\nimport { recordWhatsappPipelineEvent } from "../_shared/messaging/pipelineTelemetry.ts";\n',
            "whatsapp-send telemetry import",
        )
    text = replace_once(
        text,
        '.select("artifact_id,media_url,media_mime").eq("id", m.id).maybeSingle();',
        '.select("artifact_id,media_url,media_mime,user_id,inbound_message_id").eq("id", m.id).maybeSingle();',
        "whatsapp-send extra correlation",
    )
    text = replace_once(
        text,
        '      if (markErr) throw new Error(markErr.message);\n      if (extra?.artifact_id) {',
        '      if (markErr) throw new Error(markErr.message);\n      await recordWhatsappPipelineEvent(sb, {\n        stage: "provider_sent",\n        user_id: (extra as any)?.user_id ?? null,\n        inbound_message_id: (extra as any)?.inbound_message_id ?? null,\n        outbound_message_id: m.id, provider_message_id: providerId,\n      });\n      if (extra?.artifact_id) {',
        "whatsapp-send provider telemetry",
    )
    text = replace_once(
        text,
        '      await sb.from("outbound_messages").update({\n        status: dead ? "dead" : "queued",',
        '      await sb.from("outbound_messages").update({\n        status: dead ? "dead" : "queued",',
        "whatsapp-send catch anchor",
    )
    # Insert failure event after the retry update, before results.push.
    text = replace_once(
        text,
        '      }).eq("id", m.id);\n      results.push({ id: m.id, ok: false, error: String((e as Error).message) });',
        '      }).eq("id", m.id);\n      await recordWhatsappPipelineEvent(sb, {\n        stage: "failed", ok: false, outbound_message_id: m.id,\n        error_code: String((e as Error).message).slice(0, 120),\n        metadata: { component: "whatsapp-send", dead },\n      });\n      results.push({ id: m.id, ok: false, error: String((e as Error).message) });',
        "whatsapp-send failure telemetry",
    )
    if not dry_run:
        write(path, text)
    return str(path.relative_to(repo))


def patch_watchdog(repo: Path, dry_run: bool) -> str:
    path = repo / "supabase/functions/whatsapp-ack-watchdog/index.ts"
    text = read(path)
    text = replace_once(
        text,
        'import { getWahaAccess, loadWahaConfig } from "../_shared/messaging/waha.ts";',
        'import { getProvider, getWahaAccess, loadWahaConfig, validateWahaCredentials } from "../_shared/messaging/waha.ts";',
        "watchdog WAHA imports",
    )
    old = '''  await loadWahaConfig(supabase).catch(() => {});\n  const waha = getWahaAccess();\n\n  let stalledCount = 0;'''
    new = '''  await loadWahaConfig(supabase).catch(() => {});\n  const provider = getProvider();\n  const expectedWebhookUrl = `${SUPABASE_URL}/functions/v1/whatsapp-webhook`;\n  let webhookRepair = "not_needed";\n  let webhookHealthy = false;\n  try {\n    let validation = await validateWahaCredentials(expectedWebhookUrl);\n    webhookHealthy = validation.session.status === "WORKING" && validation.webhook.code === "ok";\n    if (provider.configured && validation.auth.ok && validation.session.exists && validation.webhook.code !== "ok") {\n      const repaired = await provider.syncWebhook(expectedWebhookUrl);\n      webhookRepair = repaired.ok ? "webhook_repaired" : "webhook_repair_failed";\n      if (repaired.ok) {\n        validation = await validateWahaCredentials(expectedWebhookUrl);\n        webhookHealthy = validation.session.status === "WORKING" && validation.webhook.code === "ok";\n      }\n    }\n    await supabase.from("provider_health_events").insert({\n      provider: "waha", ok: webhookHealthy,\n      error_masked: webhookHealthy ? "WORKING:webhook_ok" : `${validation.session.status ?? "UNKNOWN"}:${validation.webhook.code}`.slice(0, 120),\n    }).then(() => {}, () => {});\n  } catch (e) {\n    webhookRepair = "validation_failed";\n    webhookHealthy = false;\n  }\n  const waha = getWahaAccess();\n\n  let stalledCount = 0;'''
    text = replace_once(text, old, new, "watchdog webhook self-heal")
    text = replace_once(
        text,
        '    owner_alerts: ownerAlerts,\n  }));',
        '    owner_alerts: ownerAlerts,\n    webhook_repair: webhookRepair,\n    webhook_healthy: webhookHealthy,\n  }));',
        "watchdog log health",
    )
    text = replace_once(
        text,
        '    ok: deadLettered === 0,\n    processed: recoveredCount + (stuck ?? []).length + stalledCount + reconciled,\n    failed: deadLettered,',
        '    ok: deadLettered === 0 && webhookRepair !== "webhook_repair_failed" && webhookRepair !== "validation_failed",\n    processed: recoveredCount + (stuck ?? []).length + stalledCount + reconciled,\n    failed: deadLettered + (webhookRepair === "webhook_repair_failed" || webhookRepair === "validation_failed" ? 1 : 0),',
        "watchdog heartbeat health",
    )
    text = replace_once(
        text,
        '    owner_alerts: ownerAlerts,\n    results,',
        '    owner_alerts: ownerAlerts,\n    webhook_repair: webhookRepair,\n    webhook_healthy: webhookHealthy,\n    results,',
        "watchdog response health",
    )
    if not dry_run:
        write(path, text)
    return str(path.relative_to(repo))


def patch_whatsapp_session(repo: Path, dry_run: bool) -> str:
    path = repo / "supabase/functions/whatsapp-session/index.ts"
    text = read(path)
    start = text.find("async function buildOperationalStatus() {")
    end = text.find("async function rateOk", start)
    if start < 0 or end < 0:
        raise RuntimeError("whatsapp-session operational status markers not found")
    replacement = '''async function buildOperationalStatus(sb?: ReturnType<typeof createClient>) {\n  const provider = getProvider();\n  if (!provider.configured || !isWahaConfigured()) {\n    return {\n      status: "not_configured", last_seen_at: null, latency_ms: null, error_code: null,\n      webhook_ok: false,\n      data_plane: { state: "unverified", contract: "whatsapp_channel_health.v1", last_inbound_at: null, last_outbound_at: null, last_failure_at: null },\n    };\n  }\n\n  const startedAt = performance.now();\n  const [session, validation] = await Promise.all([\n    provider.getSessionStatus(),\n    validateWahaCredentials(webhookUrl()).catch(() => null),\n  ]);\n  const latencyMs = Math.round(performance.now() - startedAt);\n  const mapped = mapStatus(session?.status, null);\n  const webhookOk = validation?.webhook.code === "ok";\n  const status = mapped === "connected" && !webhookOk ? "needs_attention" : mapped;\n\n  let dataPlane = {\n    state: "unverified", contract: "whatsapp_channel_health.v1",\n    last_inbound_at: null as string | null, last_outbound_at: null as string | null, last_failure_at: null as string | null,\n  };\n  if (sb) {\n    const [inboundResp, outboundResp, failureResp] = await Promise.all([\n      sb.from("inbound_messages").select("received_at").order("received_at", { ascending: false }).limit(1).maybeSingle(),\n      sb.from("outbound_messages").select("created_at,status,sent_at,delivered_at,read_at").eq("channel", "whatsapp").order("created_at", { ascending: false }).limit(1).maybeSingle(),\n      sb.from("whatsapp_pipeline_events").select("occurred_at").or("ok.eq.false,stage.eq.failed").order("occurred_at", { ascending: false }).limit(1).maybeSingle(),\n    ]);\n    const lastInbound = (inboundResp.data as any)?.received_at as string | undefined;\n    const lastOutbound = ((outboundResp.data as any)?.sent_at ?? (outboundResp.data as any)?.created_at) as string | undefined;\n    const lastFailure = (failureResp.data as any)?.occurred_at as string | undefined;\n    let state = "unverified";\n    if (lastInbound && Date.now() - Date.parse(lastInbound) > 5 * 60_000 && (!lastOutbound || Date.parse(lastOutbound) < Date.parse(lastInbound))) {\n      state = "degraded";\n    } else if (lastInbound && lastOutbound && Date.parse(lastOutbound) >= Date.parse(lastInbound) && Date.now() - Date.parse(lastInbound) < 7 * 86_400_000) {\n      state = "verified";\n    } else if (lastFailure && (!lastOutbound || Date.parse(lastFailure) > Date.parse(lastOutbound)) && Date.now() - Date.parse(lastFailure) < 15 * 60_000) {\n      state = "degraded";\n    }\n    dataPlane = {\n      state, contract: "whatsapp_channel_health.v1",\n      last_inbound_at: lastInbound ?? null, last_outbound_at: lastOutbound ?? null, last_failure_at: lastFailure ?? null,\n    };\n  }\n\n  return {\n    status, last_seen_at: new Date().toISOString(), latency_ms: latencyMs, webhook_ok: webhookOk, data_plane: dataPlane,\n    error_code: mapped !== "connected" ? "session_not_working" : !webhookOk ? "webhook_not_verified" : null,\n  };\n}\n\n'''
    text = text[:start] + replacement + text[end:]
    text = replace_once(
        text,
        'case "operational_status": return h.ok({ ...(await buildOperationalStatus()) }, 200, extraHeaders);',
        'case "operational_status": return h.ok({ ...(await buildOperationalStatus(svc)) }, 200, extraHeaders);',
        "whatsapp-session operational status call",
    )
    if not dry_run:
        write(path, text)
    return str(path.relative_to(repo))


def verify_postconditions(repo: Path) -> None:
    checks = {
        "supabase/functions/_shared/agent/tools.ts": [
            ('[type, "both"]', False),
            ('.eq("type", type)', True),
            ('select("id,user_id,type")', True),
        ],
        "supabase/functions/_shared/anticipation/facts.ts": [
            ("resolveBehavioralDate", True),
            ("behaviorDate.eligibleForBehavior", True),
        ],
        "supabase/functions/_shared/anticipation/patterns.ts": [
            ("computeWeekdayPatternFromDailyFacts", True),
            ("truth_decision", True),
        ],
        "supabase/functions/whatsapp-webhook/index.ts": [
            ("recordWhatsappPipelineEvent", True),
            ('stage: "agent_completed"', True),
        ],
        "supabase/functions/whatsapp-ack-watchdog/index.ts": [
            ("validateWahaCredentials", True),
            ("webhook_repaired", True),
        ],
    }
    for rel, rules in checks.items():
        text = read(repo / rel)
        for needle, must_exist in rules:
            exists = needle in text
            if exists != must_exist:
                expectation = "present" if must_exist else "absent"
                raise RuntimeError(f"postcondition failed: {needle!r} must be {expectation} in {rel}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("repo", nargs="?", default=".", help="repository root")
    ap.add_argument("--allow-drift", action="store_true", help="apply even when HEAD differs from audited SHA")
    ap.add_argument("--dry-run", action="store_true", help="validate anchors without writing")
    ap.add_argument("--emit-patch", help="after applying, write git diff --binary to this path")
    args = ap.parse_args()
    repo = Path(args.repo).resolve()
    if not (repo / ".git").exists():
        print(f"ERROR: {repo} is not a git repository", file=sys.stderr)
        return 2

    head = run(["git", "rev-parse", "HEAD"], repo).stdout.strip()
    if head != BASE_SHA and not args.allow_drift:
        print(
            f"ERROR: audited base is {BASE_SHA}, but repository HEAD is {head}.\n"
            "Refusing to apply onto a different base. Re-audit/rebase the package or use --allow-drift after review.",
            file=sys.stderr,
        )
        return 3

    dirty = run(["git", "status", "--porcelain"], repo).stdout.strip()
    if dirty and not args.dry_run:
        print("ERROR: working tree is not clean; commit/stash changes first.", file=sys.stderr)
        return 4

    changed = copy_overlay(repo, args.dry_run)
    for fn in [
        patch_anticipation_facts,
        patch_anticipation_runner,
        patch_agent_tools,
        patch_anticipation_patterns,
        patch_whatsapp_webhook,
        patch_whatsapp_sender,
        patch_watchdog,
        patch_whatsapp_session,
    ]:
        changed.append(fn(repo, args.dry_run))

    if not args.dry_run:
        verify_postconditions(repo)

    print("Nino Reliability v9 anchors validated." if args.dry_run else "Nino Reliability v9 applied locally.")
    print(f"Base SHA: {head}")
    print("Changed files:")
    for rel in sorted(set(changed)):
        print(f"  - {rel}")

    if args.emit_patch and not args.dry_run:
        patch_path = Path(args.emit_patch).resolve()
        diff = run(["git", "diff", "--binary", "--", "."], repo).stdout
        patch_path.write_text(diff, encoding="utf-8")
        print(f"Patch emitted: {patch_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
