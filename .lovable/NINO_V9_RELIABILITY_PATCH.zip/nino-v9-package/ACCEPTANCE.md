# Release Gates — Nino V9

O V9 **não deve ser considerado aprovado** apenas porque build/testes passaram. Os gates abaixo são parte da definição de pronto.

## Gate A — Verdade comportamental

Pergunta no Assessor:

> Qual dia da semana eu costumo ter um maior gasto comparado com a média dos outros dias?

### Obrigatório

- `agent_runs.capability = weekday_pattern`
- execução determinística consulta a tool semanal;
- `formula_versions`/evidência identifica `weekday.behavioral-truth.v5`;
- se a base atual não cumprir os gates estatísticos, a resposta deve dizer que **ainda não há histórico confiável suficiente**;
- é proibido responder novamente algo como “R$ 782,30 por sexta” com a amostra curta que originou o incidente;
- nenhum `candidate`, `ambiguous` ou `insufficient` pode ser verbalizado como conclusão.

Golden fixture local já incluído:

- sexta 1: R$ 21,90
- sexta 2: R$ 1.396,02
- sexta 3: R$ 1.043,07
- sexta 4: R$ 0,00

Resultado obrigatório: `winner = null`.

## Gate B — Before Spending

Pergunta no Assessor:

> Se eu gastar 100 reais em lazer amanhã, qual impacto no meu saldo e na minha meta de lazer?

### Obrigatório

- capability `before_spending`;
- `run_before_spending` termina `ok`;
- nenhum erro `invalid input value for enum category_type: "both"`;
- nenhuma consulta ativa contém `category_type = both`;
- o cálculo deve vir de dados reais e não de texto livre do modelo.

Confirmação do schema:

```sql
select t.typname, array_agg(e.enumlabel order by e.enumsortorder)
from pg_type t
join pg_enum e on e.enumtypid=t.oid
where t.typname='category_type'
group by t.typname;
```

Esperado: `{income,expense}`.

## Gate C — Paridade App × WhatsApp

Enviar **a mesma pergunta financeira** primeiro no Assessor e depois no WhatsApp.

### Obrigatório

- ambos entram no `AgentCore` compartilhado;
- mesma capability;
- mesma tool/fórmula financeira;
- mesmos números financeiros (diferença permitida apenas de copy/formatação de canal);
- erro de tool nunca pode virar resposta financeira “confiável”.

## Gate D — WhatsApp E2E real

Enviar uma mensagem textual de um número já vinculado.

Dentro de poucos minutos, a cadeia deve existir:

```sql
select stage, ok, inbound_message_id, outbound_message_id, agent_run_id, error_code, occurred_at
from public.whatsapp_pipeline_events
where occurred_at > now() - interval '15 minutes'
order by occurred_at;
```

Para uma conversa normal, a sequência esperada é:

1. `webhook_received`
2. `inbound_persisted`
3. `agent_started`
4. `agent_completed`
5. `outbound_queued`
6. `provider_sent`
7. `ack_received` (quando o WAHA reportar ACK)

Não é aceitável considerar o canal saudável se só existir sessão `WORKING` sem tráfego comprovado.

## Gate E — Saúde/autorreparo WAHA

No admin, `whatsapp-session` → `operational_status` deve retornar, no mínimo:

- `status`
- `webhook_ok`
- `data_plane.state`
- `data_plane.contract = whatsapp_channel_health.v1`

O watchdog deve registrar `webhook_repaired` quando detectar sessão existente/autenticada com webhook divergente e conseguir sincronizá-lo.

Para o próprio usuário autenticado:

```sql
select public.my_whatsapp_channel_health_v1();
```

Estados válidos:

- `unlinked`
- `linked_unverified`
- `verified`
- `degraded`
- `broken`

Somente `verified` significa round-trip recente comprovado.

## Gate F — Regressão completa

Antes de publicar:

```bash
./verify_v9.sh .
```

Obrigatório:

- focused V9 tests verdes;
- typecheck verde;
- suíte completa verde;
- zero referência ativa a `weekday.behavioral-date.v4` nas Edge Functions;
- zero consulta `[type, "both"]` nas tools do agente.

## Gate de aprovação final

O release só recebe **APROVADO** quando A+B+C+D+E+F estiverem verdes. Um `401` de smoke test prova apenas que uma Edge Function existe; **não conta como teste E2E do WhatsApp**.
