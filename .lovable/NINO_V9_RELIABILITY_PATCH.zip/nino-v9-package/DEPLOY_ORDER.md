# Implantação segura V9

1. Base limpa no SHA `65c9d5ce949273a2f6611aae1792295aa6425d1c`.
2. `python3 apply_v9.py . --dry-run`.
3. `python3 apply_v9.py . --emit-patch /tmp/NINO_V9_RELIABILITY.patch`.
4. Revisar `git diff --check` e o patch emitido.
5. `./verify_v9.sh .`.
6. Commit/push do código.
7. Aplicar migration `20260807235900_nino_reliability_truth_v9.sql` uma única vez.
8. Redeploy: `agent-chat`, `agent-run`, `whatsapp-webhook`, `whatsapp-send`, `whatsapp-session`, `whatsapp-ack-watchdog`, `anticipation-tick`, `agent-proactive-tick`, `nino-intelligence-tick`.
9. Publicar frontend/app.
10. Executar A–F de `ACCEPTANCE.md` com usuário real.
11. Só então marcar o V9 como aprovado.

## Rollback

O patch evita alterar dados financeiros. Em caso de rollback do código:

- reverter o commit V9 e redeploy das funções;
- `whatsapp_pipeline_events` pode permanecer: é tabela de telemetria isolada;
- a função `my_whatsapp_channel_health_v1()` pode permanecer sem afetar contabilidade;
- não apagar eventos de telemetria para preservar evidência do incidente.
