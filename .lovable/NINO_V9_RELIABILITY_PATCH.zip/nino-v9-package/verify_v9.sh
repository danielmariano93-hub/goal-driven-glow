#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-.}"
cd "$ROOT"

echo "[1/5] Base / source contract"
if grep -R --line-number --fixed-strings 'weekday.behavioral-date.v4' supabase/functions --include='*.ts'; then
  echo "ERROR: weekday v4 still exists in active Edge source" >&2
  exit 20
fi
if grep -n --fixed-strings '[type, "both"]' supabase/functions/_shared/agent/tools.ts; then
  echo "ERROR: invalid category enum value 'both' still exists" >&2
  exit 21
fi

echo "[2/5] Focused v9 tests"
npx vitest run \
  src/test/nino-weekday-truth-v9.test.ts \
  src/test/nino-intelligence-hardening.test.ts \
  src/test/nino-weekday-separation.test.ts \
  src/test/nino-category-contract-v9.test.ts \
  src/test/nino-whatsapp-data-plane-v9.test.ts \
  src/test/nino-channel-parity-v9.test.ts \
  src/test/nino-behavioral-truth-single-source-v9.test.ts

echo "[3/5] Typecheck"
npx tsgo -p tsconfig.app.json --noEmit

echo "[4/5] Full test suite"
npx vitest run

echo "[5/5] Migration / telemetry presence"
test -f supabase/migrations/20260807235900_nino_reliability_truth_v9.sql
grep -q 'my_whatsapp_channel_health_v1' supabase/migrations/20260807235900_nino_reliability_truth_v9.sql
grep -q 'validateWahaCredentials' supabase/functions/whatsapp-ack-watchdog/index.ts
grep -q 'webhook_repaired' supabase/functions/whatsapp-ack-watchdog/index.ts

echo "LOCAL V9 GATES: PASS"
echo "Production approval still requires the authenticated App + real WhatsApp E2E gates in ACCEPTANCE.md."
